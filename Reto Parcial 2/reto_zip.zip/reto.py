from scipy import interpolate
import matplotlib.pyplot as plt
import pandas as pd
import random

# definicion de arreglos globales
hora_inter = []
temp_inter = []

# inicializacion de los arreglos
hora = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
        14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
hora_30 = hora
temperatura_inicial = []
temperatura_30 = []


# calcular valores por interpolacion
def inter(hora, temperatura):
    interpolacion_hora_temp = interpolate.interp1d(hora, temperatura)

    i = hora[0]
    for x in range(0, len(hora)*2 + 1):
        hora_inter.append(i)
        temp_inter.append(interpolacion_hora_temp(i))
        i = i + 0.5

# esta funcion se encarga de tomar los datos de la tempreratura del excel en un dia juliano en especifico


def cargar_excel():
    excel = pd.read_excel(
        "D:\Carpetas Windows\documentos\GitHub\Analisis Numerico\Reto Parcial 2\Base_datos.xls", sheet_name='Aiuaba')

    excel = excel.loc[excel["Dia Juliano"] == 92]
    excel = excel[["Temp. Interna (ºC)"]]
    return excel.to_numpy()


# impresion de graficas de los datos
def imprimir_resultados():
    plt.plot(hora, temperatura_inicial, '+-r', linewidth=2)
    plt.scatter(hora, temperatura_inicial, s=120, c='#FF0000', marker="+")
    plt.plot(hora_inter, temp_inter, '.-k', linewidth=1)
    plt.xlabel('Hora del dia')
    plt.ylabel('Temperatura interna (c)')
    plt.show()


# asignacion del arreglo de los datos obtenidos por el excel
arreglo = cargar_excel()
for x in arreglo:
    temperatura_inicial.append(x.item())

temperatura_30 = temperatura_inicial
# eliminacion de los datos 30%
datos_eliminar_num = (int)(len(temperatura_inicial) * 0.30)
print(datos_eliminar_num)
print(len(temperatura_inicial))
print(len(hora))
for i in range(0, datos_eliminar_num):
    posicion = random.randrange(1, len(temperatura_inicial))
    temperatura_30.pop(posicion)
    hora_30.pop(posicion)

print(temperatura_30)
print(hora_30)

# calculo de la interpolacion
inter(hora, temperatura_inicial)

# impresion de datos en consola
#print("valores de temperatura iniciales")
# for x in temperatura_inicial:
# print(x)
#print("Los valores de las temperatura calcualda con interpolacion son: ")
# for x in temp_inter:
#print("{:.2f} ".format(x))

imprimir_resultados()

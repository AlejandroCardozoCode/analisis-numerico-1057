from scipy import interpolate
import matplotlib.pyplot as plt

# definicion de arreglos globales
hora_inter = []
temp_inter = []


# calcular valores por interpolacion
def inter(hora, temperatura):
    interpolacion_hora_temp = interpolate.interp1d(hora, temperatura)

    i = hora[0]
    for x in range(0, len(hora)*2 + 1):
        hora_inter.append(i)
        temp_inter.append(interpolacion_hora_temp(i))
        i = i + 0.5


# inicializacion de los arreglos
hora = [7, 8, 9, 10, 11, 12, 14]
temperatura_inicial = [22.42, 27.98, 30.75, 31.44, 35.08, 36.14, 34.37]
# calculo de la interpolacion
inter(hora, temperatura_inicial)

# impresion de datos en consola

print("valores de temperatura iniciales")
for x in temperatura_inicial:
    print(x)
print("Los valores de las temperatura calcualda con interpolacion son: ")
for x in temp_inter:
    print("{:.2f} ".format(x))

# impresion de graficas de los datos
plt.plot(hora, temperatura_inicial, '+-r', linewidth=2)
plt.scatter(hora, temperatura_inicial, s=120, c='#FF0000', marker="+")
plt.plot(hora_inter, temp_inter, '.-k', linewidth=1)
plt.xlabel('Hora del dia')
plt.ylabel('Temperatura interna (c)')
plt.show()
